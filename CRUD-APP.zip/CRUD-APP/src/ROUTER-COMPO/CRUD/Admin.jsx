import React, { useContext, useEffect } from 'react'
import { data } from 'react-router-dom'
import { Detaprovider } from './Store'
import ModalsForm from './ModalsForm'

const Admin = () => {

const {data,getuserdata,handleDelete,handleShow,setcheckForm,getsingleUserData} = useContext(Detaprovider)

useEffect(()=>{
  getuserdata()
},[])

const handleEdit=(id)=>{
  setcheckForm("Edit")
  getsingleUserData(id)
  handleShow()

}
  const handleRead=(id)=>{
    setcheckForm("Read")
    getsingleUserData(id)
    handleShow()
  }
  return (
    <div>
        <ModalsForm/>
        <table className="table text-center">
  <thead>
    <tr>
      <th scope="col">Sr</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Image</th>
      <th scope="col">Age</th>
      <th scope="col">Address</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  {data.map((elm,ind)=>  <tr key={elm.id}>
      <th scope="row">{ind+1}</th>
      <td>{elm.Name}</td>
      <td>{elm.Email}</td>
      <td><img src={elm.Image} alt="" style={{height:"50px"}}/></td>
      <td>{elm.Age} </td>
      <td>{elm.Address}</td>
      <td>
         <div className="btn-group" role="group" aria-label="Basic example">

          <button type="button" className="btn btn-success mx-2" onClick={() =>handleEdit(elm.id)}>
            Edit
            </button>

          <button type="button" className="btn btn-danger mx-2" onClick={()=>handleDelete(elm.id)}>
                Delete
            </button>

          <button type="button" className="btn btn-warning" onClick={()=> handleRead(elm.id)}>
            Read
            </button>
</div>

      </td>
    </tr>)}
    
  </tbody>
</table>
        
    </div>
  )
}

export default Admin
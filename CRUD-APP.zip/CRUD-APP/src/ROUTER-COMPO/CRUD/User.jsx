import React, { useContext } from 'react'
import { Detaprovider } from './Store'

const User = () => {
const {formData:{Name,Age,Email,Image,Address}}= useContext(Detaprovider)
  return (
        <>
        <table className="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">State</th>
      
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Name</th>
      <td>{Name}</td>
      
    </tr>
    <tr>
      <th scope="row">Age</th>
      <td>{Age}</td>

    </tr>
    <tr>
      <th scope="row">Email</th>
      <td>{Email}</td>
     </tr>

      <tr>
      <th scope="row">Image</th>
      <td><img src={Image} alt="" width={"200"} height={"200"}/></td>
     </tr>

      <tr>
      <th scope="row">Address</th>
      <td>{Address}</td>
     </tr>

     
  </tbody>
</table>
        </>
  )
}

export default User
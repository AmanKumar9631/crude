import React, { useContext } from 'react'

import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { Detaprovider } from './Store';
import User from './User';


const ModalsForm = () => {
   const {show,handleClose,setformData,formData,addUserData,checkForm,edituser}=useContext(Detaprovider)

   let {Name,Email,Image,Age,Address} =formData
   const HandleAddUser=()=>{
      if (checkForm=="Add") {
        addUserData()

           }else if (checkForm=="Edit") {
             edituser()
        
     }
     handleClose()
   }


  return (
        <>


      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>{checkForm} User</Modal.Title>
        </Modal.Header>
        <Modal.Body>
            
                <div className="container ">
                <div className="row">
                <div className="col-8 mx-auto">

                {checkForm=="Read" ? <User/>:<form action="">
                
              <div className="form-floating mb-3">
              <input type="text"
               className="form-control"
                id="floatingInputName"
                 placeholder="name@example.com"
                  name='Name'
                  value={Name}
                   onChange={(e)=>setformData({...formData,[e.target.name]: e.target.value})}
                 />
              <label htmlFor="floatingInputName">Name</label>
              </div>

               <div className="form-floating mb-3">
              <input type="text"
               className="form-control"
                id="floatingInputEmail"
                 placeholder="name@example.com"
                 name='Email'
                 value={Email}
              onChange={(e)=>setformData({...formData,[e.target.name]: e.target.value})}
                 />
              <label htmlFor="floatingInputEmail">Email</label>
              </div>

               <div className="form-floating mb-3">
              <input type="text"
               className="form-control"
                id="floatingInputImage"
                 placeholder="name@example.com"
                 name='Image'
                 value={Image}
                 onChange={(e)=>setformData({...formData,[e.target.name]: e.target.value})}
                 />
              <label htmlFor="floatingInputImage">Image</label>
              </div>

               <div className="form-floating mb-3">
              <input type="text"
               className="form-control"
                id="floatingInputAge"
                 placeholder="name@example.com"
                  name='Age'
                  value={Age}
                  onChange={(e)=>setformData({...formData,[e.target.name]: e.target.value})}
                 />
              <label htmlFor="floatingInputAge">Age</label>
              </div>

               <div className="form-floating mb-3">
              <input type="text"
               className="form-control"
                id="floatingInputAddress"
                 placeholder="name@example.com"
                 name='Address'
                 value={Address}
                 onChange={(e)=>setformData({...formData,[e.target.name]: e.target.value})}
                 />
              <label htmlFor="floatingInputAddress">Address</label>
              </div>
                          <Button variant="success" type='button' onClick={HandleAddUser}>
                           {checkForm} User
                          </Button>
              </form>}



                </div>
                </div>
                </div>
            
        </Modal.Body>
        <Modal.Footer>
         

        </Modal.Footer>
      </Modal>
    </>
   
  )
}

export default ModalsForm
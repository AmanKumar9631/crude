import { createContext } from "react";

export const Detaprovider= createContext([])
import React from 'react'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import App from '../App'
import Home from './CRUD/Home'
import Admin from './CRUD/Admin'

const RouterCompo = () => {
const Router= createBrowserRouter([
    {
        path:'/',
        element:<App/>,
        children:[
            {
                path:'/Home',
                element:<Home/>
            },
             {
                path:'/Admin',
                element:<Admin/>
             }
        ]
    }
])
  return (
        <>
        <RouterProvider router={Router}></RouterProvider>
        </>


  )
}

export default RouterCompo
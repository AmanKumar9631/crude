import React, { useState } from 'react'

const Inpv = () => {
let[inp,setinp]= useState()

  return (
         <div className="container">
        <div className="row">
            <div className="col-6 m-5">
                <input type="text"  className='form-control' onChange={(e)=> setinp(e.target.value)}/>
                <h1>{inp}</h1>
            </div>
        </div>
    </div>
  )
}

export default Inpv
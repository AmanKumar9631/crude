import React, { useRef, useState } from 'react'

const StopWatch = () => {
  let [stops,setstop]= useState(0)
    let refbtn= useRef(null)
    
  function starbtn() {
    refbtn.current=setInterval(() => {
        setstop(stops => stops+1)
    }, 1000);
  }
   
  function stoptn(params) {
    clearInterval(refbtn.current)
     refbtn.current=null
  }
   
  function cleartn() {
     stoptn()
     setstop(0)
    
  }
  return (
        <div className="container">
        <div className="row">
            <div className="col-6 bg-info m-4">
                <div className='border border-success text-center'>
                    <h1>STOP WATCH</h1>
                    <h1>{stops}</h1>

                     <div>
                        <button className='btn btn-success' onClick={starbtn}>start</button><br /><br />
                        <button className='btn btn-warning' onClick={stoptn}>Stop</button><br /><br />
                        <button className='btn btn-danger' onClick={cleartn}>Clear</button>
                     </div>
                    
                </div>
            </div>
        </div>
        </div>
  )
}

export default StopWatch
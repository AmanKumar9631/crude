import React, { useState } from 'react'
import { deta } from './Deta'
import Product from './Product'

const Dummy = () => {
let[inptn,setinptn]=useState("")
let [Products,setprodunct]=useState(deta)
    const searchinp=(e)=>{

    let filterpro= deta.filter((elm)=> elm.title.toLocaleLowerCase(). includes(inptn.toLocaleLowerCase()))
            setprodunct(filterpro)
    }
  return (
        <div className='container'>
        <div className="row">


        <div className='my-3'>
            <input type="text" placeholder='Enter Items Name' className='text-center'onChange={(e)=>setinptn(e.target.value)} />
             <button className='btn btn-success m-2' onClick={searchinp}>Search</button>
        </div>
    

        {Products.map((elm,ind)=><Product key={ind} elm={elm}/>)}

        <input type="text" />
        </div>
        
        </div>
  )
}

export default Dummy
import React, { useEffect, useState } from 'react'

const TimeWatch = () => {
let [count,setcount]= useState(0)

let times= new Date()
// let[time,settime]= useState()

// function countbtn() {
//     settime(times)
// }
// useEffect(()=>{
//     countbtn()
// })
  return (
        <div className="container">
        <div className="row">
            <div className="col-6 border border-success text-center bg-info-subtle">

                <h1>Counter</h1>
                <h1>{count}</h1>
                 <h1>{times.toLocaleDateString()}- {times.toLocaleTimeString()}</h1>
                <div>
                    <button className='btn btn-success' onClick={((elm)=> setcount(++count))}>Stabtn</button><br /><br />
                    <button className='btn btn-danger' onClick={((elm)=> setcount(--count))}>Delbtn</button><br /><br />
                    <button className='btn btn-warning' onClick={((elm)=> setcount(0))}>Clrbtn</button>
                </div>
            </div>
        </div>
        </div>
  )
}

export default TimeWatch
import React from 'react'

const Product = ({elm:{thumbnail,title,category,rating}}) => {
let inpval= Math.round(rating)
let setinp= []
for(let num=1; num<=inpval; num++){
     setinp.push(num)
}
  return (
    <div className='col-3'>
         <div class="card text-center" style={{height:"58vh"}}>
  <img src={thumbnail} class="card-img-top" alt="..." style={{height:"28vh"}}/>
  <div class="card-body">
    <h5 class="card-title"> {title}</h5>
     <p>{category}</p>
     <p>Rating :{setinp.map((elm,ind)=><i key={ind} class="fa-solid fa-star"></i>)}</p>
    

  </div>
</div>
       
    </div>
  )
}

export default Product
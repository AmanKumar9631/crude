import React from 'react'
import NavsBars from './ROUTER-COMPO/CRUD/NavsBars'
import { Outlet } from 'react-router-dom'
import { Detaprovider } from './ROUTER-COMPO/CRUD/Store'
import axios from 'axios'
import { useState } from 'react'

const App = () => {
  //data from api
  let[data,setdata]=useState([])
  //modals data/
  const [show, setShow] = useState(false);
//get All data by Api//
   //get Form Data
let[formData,setformData]= useState({
   
  })

  //check Form

   let [checkForm,setcheckForm]=useState("edit")

   // Id State
    let[userid, setuserid]= useState("")



  

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  //get ALl data by Api
  const getuserdata=async ()=>{
  const res=await axios.get
  ("https://685f920cc55df675589ea999.mockapi.io/User/UserData")
   setdata(res.data)

}
// Post one user Data
 const addUserData= async()=>{
    await axios.post("https://685f920cc55df675589ea999.mockapi.io/User/UserData",formData)
    getuserdata()
 }
   //handle Delete
   const handleDelete= async(id)=>{
        await axios.delete(`https://685f920cc55df675589ea999.mockapi.io/User/UserData/${id}`)
        getuserdata()
   }
   
   //get single User Data
    const getsingleUserData=async(id)=>{
     let singleData= await axios.get(`https://685f920cc55df675589ea999.mockapi.io/User/UserData/${id}`)
         setformData(singleData.data)
          setuserid(singleData.data.id)
          }
        //Edit User
         const edituser= async()=>{
        
          
          await axios.put(`https://685f920cc55df675589ea999.mockapi.io/User/UserData/${userid}`,formData)
              getuserdata()
         }
  return (
      <>
     <Detaprovider 
     value={{data,
     getuserdata,
     handleClose,
     handleShow,
     show,
     setformData,
     formData,
     addUserData,
     handleDelete,
     checkForm,
     setcheckForm,
     getsingleUserData,
     edituser,
      
     
     }}
     >
     <div className="container">
       <NavsBars/>
      <Outlet/>
     </div>
     </Detaprovider>
      </>
  )
}

export default App